//
//  UBSDK.h
//  UBSDK
//
//  Created by md212 on 2019/4/23.
//  Copyright © 2019年 ttss. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for UBSDK.
FOUNDATION_EXPORT double UBSDKVersionNumber;

//! Project version string for UBSDK.
FOUNDATION_EXPORT const unsigned char UBSDKVersionString[];

#import <UBSDK/UBDataObjc.h>
// In this header, you should import all the public headers of your framework using statements like #import <UBSDK/PublicHeader.h>


